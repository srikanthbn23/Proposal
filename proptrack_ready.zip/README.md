# PropTrack App

Simple demo app deployed via Vercel.
