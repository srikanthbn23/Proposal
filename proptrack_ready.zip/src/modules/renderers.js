export function render() {
  return `<p>App is working 🚀</p>`;
}
