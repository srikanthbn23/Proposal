import { render } from './modules/renderers.js';

document.getElementById('app').innerHTML = render();
